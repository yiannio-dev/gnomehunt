extends CharacterBody2D


var SPEED = 100.0
const JUMP_VELOCITY = -300.0
var spin = false
var dizz = false
var can_move = true
var probab
var safety = 1
var hp = 3
var wait = 2

func _physics_process(delta: float) -> void:
	if Input.is_key_pressed(KEY_SHIFT):
		SPEED = move_toward(SPEED,300,SPEED/3)
	else:
		SPEED = move_toward(SPEED,100,SPEED/3)
# Get the input direction and handle the movement/deceleration.
# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_axis("ui_left", "ui_right")
	var direction2 := Input.get_axis("ui_up", "ui_down")

	if direction and !direction2:
		velocity.x = direction * SPEED

	if direction2 and !direction:
		velocity.y = direction2 * SPEED
	if direction2 and direction:
		velocity = Vector2 (direction, direction2).normalized()*SPEED
	if !direction2:
		velocity.y = move_toward(velocity.y,0,SPEED)
	if !direction:
		velocity.x = move_toward(velocity.x,0,SPEED)
	move_and_slide()
	animations()

func animations():
	if velocity.y < 0:
		$AnimatedSprite2D.play("up")
	elif velocity.y > 0:
		$AnimatedSprite2D.play("down")
	elif velocity.x < 0:
		$AnimatedSprite2D.play("left")
	elif velocity.x > 0:
		$AnimatedSprite2D.play("right")
	else:
		$AnimatedSprite2D.play("idle")
