extends CharacterBody2D

const SPEED = 100.0
const FLEE_DISTANCE = 150.0 # Reduced slightly to prevent clipping through massive walls

@onready var nav_agent: NavigationAgent2D = $NavigationAgent2D

var calc_timer: float = 0.0
const CALC_INTERVAL: float = 0.15 # Slightly faster updates feel more responsive for fleeing

func _ready() -> void:
	nav_agent.path_desired_distance = 15.0
	nav_agent.target_desired_distance = 15.0
	await get_tree().physics_frame

func _physics_process(delta: float) -> void:
	var player = $"../player"
	var bath = $"../player/points"
	
	if not player or not bath:
		return

	# 1. Update the flee destination dynamically
	calc_timer += delta
	if calc_timer >= CALC_INTERVAL:
		calc_timer = 0.0
		
		# Get direction directly AWAY from player
		var dir_away = (global_position - player.global_position).normalized()
		
		# Project a raw target destination
		var raw_flee_target = global_position + (dir_away * FLEE_DISTANCE)
		
		# FIX: Ask the navigation map where the absolute closest WALKABLE point is to our raw target
		var map_rid = nav_agent.get_navigation_map()
		var valid_flee_target = NavigationServer2D.map_get_closest_point(map_rid, raw_flee_target)
		
		# Only update if the agent isn't being forced to walk back TOWARDS the player to reach it
		if (valid_flee_target - global_position).dot(dir_away) > -0.2:
			nav_agent.target_position = valid_flee_target
		else:
			# Alternate fallback: If straight back is a dead end, try to pick a random perpendicular escape path
			var side_dir = Vector2(-dir_away.y, dir_away.x) if randf() > 0.5 else Vector2(dir_away.y, -dir_away.x)
			var escape_fallback = global_position + (side_dir * FLEE_DISTANCE)
			nav_agent.target_position = NavigationServer2D.map_get_closest_point(map_rid, escape_fallback)
	
	# 2. Check if reached destination
	if nav_agent.is_navigation_finished():
		velocity = Vector2.ZERO
		return

	# 3. Get next step on the TileMap path
	var next_path_pos = nav_agent.get_next_path_position()
	
	# 4. Calculate direction TOWARD the next path point
	var dir = (next_path_pos - global_position).normalized()
	
	# 5. Set velocity
	velocity = dir * SPEED
	
	# 6. Handle animations
	if dir.y < -0.1:
		$gnome.play("UP")
	elif dir.y > 0.1:
		$gnome.play("DOWN")
	elif dir.x > 0.1:
		$gnome.play("RIGHT")
		$gnome.flip_h = false
	elif dir.x < -0.1:
		$gnome.play("RIGHT")
		$gnome.flip_h = true
	
	# 7. UI Update & Scene Management
	bath.text = "Gnomes: " + str(get_parent().points) + "/5"
	if get_parent().points >= 5:
		get_tree().change_scene_to_file("res://scenes/win.tscn")
		
	# 8. Execute movement
	move_and_slide()

func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.name == "player":
		get_parent().points += 1
		queue_free()
